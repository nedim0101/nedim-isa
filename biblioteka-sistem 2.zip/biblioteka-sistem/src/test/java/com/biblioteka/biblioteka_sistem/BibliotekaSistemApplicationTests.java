package com.biblioteka.biblioteka_sistem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliotekaSistemApplicationTests {

	@Test
	void contextLoads() {
	}

}
